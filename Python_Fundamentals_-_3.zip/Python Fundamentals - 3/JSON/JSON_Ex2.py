import json

# dict
person = {"name": "John", "age": 30, "city": "New York", "hasChildren": False, "titles": ["engineer", "coder"]}

with open('person2.json', 'w') as f:
    json.dump(person, f)