# FROM JSON to Python (Deserialization, Decode)

import json
from json import JSONDecodeError

person_json = """
{
    "age": 30,
    "city": "New York",
    "hasChildren": false, 
    "name": "John",
    "titles": [
        "engineer",
        "programmer"
    ]
}
"""
try:
    person = json.loads(person_json)
    print(person['name'])
    print(person)
except JSONDecodeError as e:
    print("Error occurred while loading. The string is not in the valid JSON format")
    print(e)

