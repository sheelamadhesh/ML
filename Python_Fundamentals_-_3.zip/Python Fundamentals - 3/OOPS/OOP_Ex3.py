class Student:

    def __init__(self, age, name, cgpa):
        print("Creating a student object")
        self.age = age
        self.name = name
        self.cgpa = cgpa

    def study(self):
        print("I am learning something")


    def __repr__(self):
        return "Student object: "+ self.name


class Course:

    def __init__(self, name):
        self.name = name
        self.list_of_learners = []

    def add_a_student(self, stud_obj): # enroll
        self.list_of_learners.append(stud_obj)

    def find_topper(self):
        max_cgpa = 0
        topper = None
        for stud in self.list_of_learners:
            if stud.cgpa > max_cgpa:
                max_cgpa = stud.cgpa
                topper = stud

        return topper

    def __repr__(self):
        return f"Course Name: {self.name}"


student1 = Student(25, "Matt", 4)
student2 = Student(28, "Sachin", 5)
student3 = Student(28, "Swetha", 4.5)
student4 = Student(28, "Hitesh", 10)

python_course = Course("Python Fundamentals")
print(python_course)

python_course.add_a_student(student2)
python_course.add_a_student(student1)
python_course.add_a_student(student3)
python_course.add_a_student(student4)

print("Topper is:", python_course.find_topper())

