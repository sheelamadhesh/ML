from abc import ABC, abstractmethod

class Shape(ABC):
    @abstractmethod
    def area(self):
        print()
        return 4

    @abstractmethod
    def perimeter(self):
        pass

class Circle(Shape):
    def __init__(self, radius):
        self.radius = radius

    def area(self):
        print(self)
        print(id(self))
        return 3.14 * self.radius * self.radius

    def perimeter(self):
        return 2 * 3.14 * self.radius

class Square(Shape):
    def __init__(self, side):
        self.side = side

    def area(self):
        return self.side * self.side

    def perimeter(self):
        return 4 * self.side

# Trying to create an object of the abstract class (Shape) will raise an error:
# shape = Shape()  # Raises TypeError: Can't instantiate abstract class Shape with abstract methods area, perimeter

# Create objects of the subclasses
circle = Circle(5)
square = Square(4)

# Calling methods on the subclasses
print(circle.area())     # Output: 78.5
print(circle.perimeter())  # Output: 31.400000000000002

print(square.area())     # Output: 16
print(square.perimeter())  # Output: 16


