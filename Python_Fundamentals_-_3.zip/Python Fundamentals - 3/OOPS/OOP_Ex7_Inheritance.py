# base class  - super class -- parent class
class Animal:

    def __init__(self):
        self.legs = 4

    def eat(self):
        print("I can eat!")
        print("my name is ", self)

    def sleep(self):
        print("I can sleep!")


# derived class - sub class - child class
class Dog(Animal):

    # overriding
    def eat(self):
        print("I'm a dog and I eat differently")

    def bark(self):
        print("My legs count: ", self.legs)
        print("I can bark! Woof woof!!")


class Cat(Animal):

    def meow(self):
        print("My legs count: ", self.legs)
        print("I can meow!!")

# Create object of the Dog class
dog1 = Dog()

# Calling members of the base class
# dog1.eat()
# dog1.sleep()

# Calling member of the derived class
dog1.bark()

cat1 = Cat()
# cat1.eat()
# cat1.sleep()
cat1.meow()

# cat2 = Cat()
# cat2.eat()
# cat2.sleep()
# cat2.meow()


class Fish:
    def a(self):
        print("I'm from Fish Class")


class Bird:
    def a(self):
        print("I'm from Bird Class")

class FlyingFish(Bird, Fish):
    def a(self):
        print(super(Fish))

ff = FlyingFish()
ff.a()