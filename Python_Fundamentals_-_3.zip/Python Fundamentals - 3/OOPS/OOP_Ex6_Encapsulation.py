# Python program showing a use
# of get() and set() method in
# normal function

class Person:
    def __init__(self, name, age):
        self.name = name # public
        self._address = "ok"
        self.__age = age  # protected

    # getter method
    def get_age(self):
        if (self.__age < 0):
            print("This is not a valid age")
            return -1
        return self.__age

    # setter method
    def set_age(self, x):
        if x < 0:
            self.__age = 0
            return
        self.__age = x

    def __repr__(self):
        return "age from object: " + str(self.__age)

p1 = Person("Matt", 20)

p2 = Person("Raju", 30)

# setting the age using setter
p1.set_age(21)

# retrieving age using getter
print(p1.get_age())

print(p1._Person__age)

p1.__age = -50


print(p1.__age)
print(p1._Person__age)
print(p1.get_age())


print(p1)
print(p1.__age)
print(p1._Person__age)
print(p1.get_age())



