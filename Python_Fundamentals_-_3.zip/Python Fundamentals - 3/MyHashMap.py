class MyHashMap:

    def __init__(self):
        self.size = 997
        self.bucket = [None] * self.size

    def calc_hash_value(self, key):
        return key % self.size

    def put(self, key: int, value: int) -> None:
        hash_value = self.calc_hash_value(key)
        if self.bucket[hash_value] is None:
            self.bucket[hash_value] = [[key, value]]
        else:
            for item in self.bucket[hash_value]:
                if item[0] == key:
                    item[1] = value
                    return
            self.bucket[hash_value].append([key, value])

    def get(self, key: int) -> int:
        hash_value = self.calc_hash_value(key)
        if self.bucket[hash_value] != None:
            for item in self.bucket[hash_value]:
                if item[0] == key:
                    return item[1]
        return -1

    def remove(self, key: int) -> None:
        hash_value = self.calc_hash_value(key)
        if self.bucket[hash_value] is not None:
            for item in self.bucket[hash_value]:
                if item[0] == key:
                    self.bucket[hash_value].remove(item)